package osori.example.cbhs_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbhsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbhsApiApplication.class, args);
	}

}
